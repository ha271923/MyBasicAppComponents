
var G_FADE_EFFECT_SPEED = 400;
var G_MOVE_EFFECT_SPEED = 400;
var G_ANIMATE_SPEED     = 300;
var G_ANIMATE_EASING = "swing";  //"swing","linear"


var G_VIDEO_AUTOPLAY = true;  // 一開始是否自動播放
var G_VIDEO_LOOPPLAY = false;  // 是否循環播放
var G_MUTED    = true;  // 是否靜音
var G_WAIT_SEC = 7000; //選單不動時幾秒後自動關閉，1000毫秒=1秒

var G_TARGET_FLOW = 1;   // match "#subpopmenu01";
var G_TARGET_PAGE = 1;   //need int

var G_TIMER_ID;
var G_TIMER_ID2;

var G_MAIN_DEMO_SEC = 10000;

var G_PARENT_PAGE = "";

var G_BODY_ZOOM = 1;

//set Oringnal design size
var G_DESIGN_WIDTH = 360;
var G_DESIGN_HEIGHT = 640;


//set target device viewport size 
var G_VIEWPORT_WIDTH = 360;
var G_VIEWPORT_HEIGHT = 640;