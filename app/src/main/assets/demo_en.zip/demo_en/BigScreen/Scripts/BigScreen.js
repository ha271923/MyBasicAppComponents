function onDeviceReady() {
    // Fast-click to elliminate the delay of 300ms
    FastClick.attach(document.body);
}





//所有TryItOut按鈕會呼叫的PhoneGap,Cordova API皆寫於此
function executeExternalAPI() {
    var sUrlHead = "https://demoflo.com:";
    var RedirectNum = "1";
    var iPageId = (G_TARGET_FLOW + 2) * 10 + G_TARGET_PAGE;
    
    //alert(iPageId);
    switch (iPageId) {
    case 41:
        RedirectNum = "4";
        break;
    case 42:
        RedirectNum = "5";
        break;
    case 43:
        RedirectNum = "6";
        break;  
    case 44:
        RedirectNum = "7";
        break; 
    case 51:
        RedirectNum = "8";
        break;
    case 52:
        RedirectNum = "9";
        break;
    case 61: 
        RedirectNum = "10";
        break;
    case 62: 
        RedirectNum = "11";
        break;            
    case 63: 
        RedirectNum = "12";
        break;  
    case 64: 
        RedirectNum = "13";
        break;             
    default:
        alert("請於 BigScreen.js 中 executeExternalAPI( ) 加入 case [" + iPageId + "]之程式段，以呼叫PhoneGap 或 Cordova API 來存取 Local Resource.");
            return;
        break;
    }

    var sUrl = sUrlHead + RedirectNum;
    //self.location=sUrl;
    window.open(sUrl, '_blank');

}




function setTargetFlow(inFlowNum) {
    //f (inFlowId.substring(0,1)!="#"){
    //   G_TARGET_FLOW = "#" + inFlowId;
    //}else{
    //    G_TARGET_FLOW = inFlowId;
    //}
    G_TARGET_FLOW = inFlowNum;
    G_TARGET_PAGE = 1;
    
}

function hideMainMenu() {
    G_PARENT_PAGE = "";
	$("#viewbox").fadeOut(G_FADE_EFFECT_SPEED);
    clearInterval(G_TIMER_ID);
    //G_TIMER_ID = setTimeout("autoDemo()", 10000); //每5秒更新一次



}



function showMainMenu() {
    resetSeconds();
    G_PARENT_PAGE = "";
    clearInterval(G_TIMER_ID);
    clearInterval(G_TIMER_ID2);
    

    
    //$(".menuitem").hide();
    $('.menuitem').css({display:'block',opacity: "0",top: "60px"});
    
    $("#displaywall").animate({"margin-left": "0px"}, G_ANIMATE_SPEED);

    
    $("#viewbox").fadeIn(1500);
    
    $("#submenu01").animate({ opacity: 0.8, marginTop: "0px" }, G_ANIMATE_SPEED);
    $("#submenu02").delay(400).animate({ opacity: 0.8, marginTop: "0px"}, G_ANIMATE_SPEED);
    $("#submenu03").delay(800).animate({ opacity: 0.8, marginTop: "0px"}, G_ANIMATE_SPEED);
    $("#submenu04").delay(1200).animate({ opacity: 0.8, marginTop: "0px" }, G_ANIMATE_SPEED);
    
    //$('.menuitem').first().animate({ opacity: 0.8, top: "0px",zoom:"1" }, 800,"swing", //function() {
//         $(this).next().animate({ opacity: 0.8, top: "0px" ,zoom:"1"},600,"swing", //arguments.callee);
//        });
    //$("#viewbox").css("top","-1920px").fadeIn(5).animate({"top":"0px"},G_MOVE_EFFECT_SPEED);
    
    
}





function xreloadStartAdWhenEnded() {
	if ($("#videobody")[0].ended){
		clearInterval(G_TIMER_ID2);
		$("#videobody")[0].pause();
    	$("#videobody source")[0].src="Demo.mp4";
    	$("#videobody")[0].loop=true;
    	$("#videobody")[0].load();
    	$("#videobody")[0].play();
	}
}

function reloadStartAdWhenEnded(){
    if ($("#videobody")[0].ended){
        clearInterval(G_TIMER_ID2);
        $("#videobody")[0].pause();
        $("#videobody source")[0].src="Demo.mp4";
        $("#videobody")[0].loop=true;
        $("#videobody")[0].load();
        $("#videobody")[0].play();      
        $("#viewbox").fadeIn(G_FADE_EFFECT_SPEED);
    }
}


function moveCursor() {

}

function waitNSecThenDo(inSec,inFunc){
    iTimeLine = iTimeLine + inSec;
    setTimeout(inFunc, inSec);

}

function returnToMainMenu(){
        $("#displaywall").animate({"margin-left":"0px"},G_MOVE_EFFECT_SPEED);
        clearInterval(G_TIMER_ID);
        G_TIMER_ID = setInterval("hideMainMenu()", G_WAIT_SEC); //每5秒更新一次            
}


function playAnimationAgain(){
    var iPageId = (G_TARGET_FLOW+2)*10+G_TARGET_PAGE;
    playLoopAniAndWaitToMenu();

}


function playLoopAniAndWaitToMenu(){

    clearInterval(G_TIMER_ID);
    clearInterval(G_TIMER_ID2);
    
    var iPageId = (G_TARGET_FLOW+2)*10+G_TARGET_PAGE;
    
    
    
    G_TIMER_ID = setTimeout("showMainMenu()", 90000); 
    
    
    
    
    if (iPageId==33){
        G_TIMER_ID2 = setInterval("switchGallery('RIGHT')", 3000); 
        return;
    }
    
    if (iPageId==61){
        playAnimation();
        G_TIMER_ID2 = setInterval("playAnimation()", 8500); 
        return;
    }  
    if (iPageId==62){
        playAnimation();
        G_TIMER_ID2 = setInterval("playAnimation()", 9000); 
        return;
    }     
    
    if (iPageId==64){
        playAnimation();
        G_TIMER_ID2 = setInterval("playAnimation()", 6500); 
        return;
    }    
    
    
    if (iPageId==63){
        
        G_TIMER_ID2 = setInterval("switchSkin('RIGHT')", 3000); 
        return;
        
    }else{
        playAnimation();
        G_TIMER_ID2 = setInterval("playAnimation()", 10000); 
    }
    

    
    

    
}



function playAnimation(inFrameId){
    
    return;
    
    
    var iFadeInTime = 900;
    var iDelayTime =1500;
    
    if (inFrameId==undefined){
        inFrameId = (G_TARGET_FLOW+2)*10+G_TARGET_PAGE;
    }
    
    
    //$("#video43")[0].pause();   //stop video clip play   
    $("#ImgSoundWave").removeClass("moveforever");

    
    if (inFrameId==42){
        $("#img42Bright").css("display","none");
        $("#img42Bright").delay(iDelayTime).fadeIn(1500).delay(iDelayTime*2).fadeOut(1000);
    } 
    
/*    if (inFrameId==43){
        $("#video43")[0].pause();
        $("#video43 source")[0].src="hyperlaspe_video.mp4";
        $("#video43")[0].loop=true;
        $("#video43")[0].load();
        $("#video43")[0].play();        
    }*/
    
    
    if (inFrameId==51){
        $("#ImgBlueLine").fadeOut();
        $("#ImgRedLine").fadeOut();
        $("#ImgCurveLine").fadeOut();
        $("#ImgBlueLine").delay(iDelayTime).hide(0).fadeIn(iFadeInTime,function(){
            $("#ImgRedLine").hide(0).fadeIn(iFadeInTime,function(){
            $("#ImgCurveLine").hide(0).fadeIn(iFadeInTime).delay(iDelayTime*2);
            });
        });
        
        
    }
    
    if (inFrameId==52){
        var iMoveSpeed1=1200;
        var iMoveSpeed2=300;
        
        $("#ImgSoundWave").removeClass("moveforever").addClass("moveforever");
        
        
        //$("#ImgSoundWave").animate({"background-position-x":"9080px"},4000).animate({"background-position-x":"0px"},4000);
        //$("#ImgSoundWave").fadeIn(600).delay(iDelayTime*3).fadeOut(600);
        $("#ImgSoundWave").fadeIn(20);
        
        if ($("#ImgPhone").css("margin-left")!="-460px"){
        $("#ImgPhone").css("margin-left","-803px").delay(iDelayTime).show().animate({"margin-left":"-120px"},iMoveSpeed1).animate({"margin-left":"-151px"},iMoveSpeed2);
        }
    }

    if (inFrameId==61){
        var iMoveSpeed1=1200;
        var iMoveSpeed2=200;
        $("#ImgPhone61").show().animate({"margin-left":"-826px"},0).delay(300).animate({"margin-left":"-125px"},iMoveSpeed1).animate({"margin-left":"-146px"},iMoveSpeed2).delay(6000).fadeOut(600);
        $("#ImgAndroidRobot").show().animate({"left":"462px"},0).delay(300).animate({"left":"-17px"},iMoveSpeed1).animate({"left":"0px"},iMoveSpeed2).delay(6000).fadeOut(600);
        
        $("#ImgDesktop01").delay(500+iMoveSpeed1+iMoveSpeed1+400).fadeIn(300).delay(1500).delay(1500).fadeOut(600);
        $("#ImgDesktop02").delay(500+iMoveSpeed1+iMoveSpeed1+700+1500).fadeIn(300).delay(2000).fadeOut(600);
    }
    
    if (inFrameId==62){
        
        $("#FingerPrint").delay(1000).fadeIn(400,function(){});
        $("#Img62Screen").delay(1800).fadeIn(400,function(){});
        $("#FingerPrint").delay(1000).fadeOut(400,function(){});
        $("#Img62PayStep01").delay(3500).fadeIn(300).delay(3500).fadeOut(500);
        $("#Img62PayStep02").delay(3500).fadeIn(300).delay(2000).fadeOut(10);
        $("#Img62PayStep03").delay(5000).fadeIn(300).delay(2000).fadeOut(500);
        $("#Img62Screen").delay(5000).fadeOut(500);
        //$("#FingerPrint").delay(3000).fadeIn(600).delay(2000).fadeOut(600);
        //$("#Img62Screen").delay(3800).fadeIn(400).delay(4000).fadeOut(1200);
        
/*
        $("#FingerPrint").hide().delay(1400).fadeIn(500,function(){
            $("#Img62Screen").delay(300).fadeIn(300,function(){
                $("#FingerPrint").delay(600).fadeOut(400,function(){
                    $("#Img62PayStep01").delay(300).fadeIn(400).delay(1800).fadeOut(1000);
                    $("#Img62PayStep02").delay(2500).fadeIn(100).delay(2000).fadeOut(1000);
                    $("#Img62Screen").delay(3300).fadeOut(1000);
                });
            
            });
        });

 */       
        
        //$("#BlackScreen").show().delay(4000).delay(2000).fadeIn(1000).delay(2000).delay(1000).fadeOut(4000);
        
        //$("#FingerPrint").hide().delay(4000).fadeIn(2000).delay(1000).delay(2000).fadeOut(1000).delay(4000).fadeOut(0);
        
        //$("#BlackScreen").delay(2000).fadeIn(1000,function(){
        //$("#FingerPrint").fadeIn(200,function(){
        //$("#BlackScreen").fadeOut(200,function(){
        //$("#FingerPrint").delay(400).fadeOut(400,function(){
        //$("#BlackScreen").delay(2000).fadeIn(2000);
        //});
        //});
        //});
        //});
        
        
        //$("#BlackScreen").show().delay(6000).fadeOut(200).delay(3400).fadeIn(1500);
        
        //$("#FingerPrint").delay(5600).fadeIn(400).delay(200).fadeOut(400).delay(3000).delay(1500);

    } 
    

    
    

    if (inFrameId==64){
        $("#batteryQuickTop").animate({"margin-bottom":"86px","background-position-x":"0px"},0).delay(300).show().animate({"margin-bottom":"250px","background-position-x":"330px"},2000).delay(iDelayTime*2).fadeOut(200);
        
     $("#batteryNormal").animate({"height":"0px"},0).delay(300).show().animate({"height":"75"},2000).delay(iDelayTime*2).fadeOut(200);
    
    }
    
    
    
    
    
}



function switchSound(){
        if ($("#btnSoundSwitch").hasClass("soundon")){
            $("#btnSoundSwitch").removeClass("soundon").addClass("soundoff");
        }else{
            $("#btnSoundSwitch").removeClass("soundoff").addClass("soundon");
        }
    
        autoScale();
}



var G_GALLERY_IDX=1;

function switchGallery(inDirection){
    resetSeconds();
    //alert(G_GALLERY_IDX);
    
    if (inDirection=="LEFT"){
        G_GALLERY_IDX = G_GALLERY_IDX - 1;
    }
    
    if (inDirection=="RIGHT"){
        G_GALLERY_IDX = G_GALLERY_IDX + 1;
    }    
    
    if (G_GALLERY_IDX < 1){
        //G_GALLERY_IDX=4;
        //return;
    }
    if (G_GALLERY_IDX > 4){
        //G_GALLERY_IDX=1;
        //return;
    }
    
    //alert(G_GALLERY_IDX);
    
    var iSwitchWidth = G_DESIGN_WIDTH;
    
    var iNewLeft = 0-((G_GALLERY_IDX-1)*iSwitchWidth);
    
    $("#ImgBGSlide").animate({"background-position-x":iNewLeft+"px"},G_ANIMATE_SPEED/3,"swing");   
    
    //$("#test_info").text(G_GALLERY_IDX);

}





var G_SKIN_PIN=3;

function switchSkin(inDirection){
    resetSeconds();
    
    if (inDirection=="LEFT"){
        G_SKIN_PIN = G_SKIN_PIN - 1;
    }
    if (inDirection=="RIGHT"){
        G_SKIN_PIN = G_SKIN_PIN + 1;
    }    
    
    if (G_SKIN_PIN <= 0){
        G_SKIN_PIN=7;
        //return;
    }
    if (G_SKIN_PIN >= 8){
        G_SKIN_PIN=1;
        //return;
    }
    
    var iStartLeft = 93;
    var iSwitchWidth = 195;
    
    var iNewLeft = iStartLeft - ((G_SKIN_PIN-1)*iSwitchWidth);
    
    $("#ImgSkinList").animate({"zoom":"1","left":iNewLeft+"px"},G_ANIMATE_SPEED/3,"swing");
}


function blockDefaultEvent(inId){
    var objId = inId;
    
    //$(objId).on("touchstart",function(e) {
    //            e.preventDefault();
    //});
    //$(objId).on("touchend",function(e) {
    //            e.preventDefault();
    //});   
     $(objId).on("touchmove",function(e) {
                e.preventDefault();
    });   
}




function touches(ev){ 
         if(ev.touches.length==1){ 
             var oDiv=document.getElementById('test_info'); 
             switch(ev.type){ 
                 case 'touchstart': 
                     oDiv.innerHTML='Touch start('+ev.touches[0].clientX+', '+ev.touches[0].clientY+')'; 
                     ev.preventDefault();  //阻止出现滚动条 
                    break; 
                 case 'touchend': 
                     oDiv.innerHTML='Touch end('+ev.changedTouches[0].clientX+', '+ev.changedTouches[0].clientY+')'; 
                     break; 
                 case 'touchmove': 
                     oDiv.innerHTML='Touch move('+ev.changedTouches[0].clientX+', '+ev.changedTouches[0].clientY+')'; 
                     break; 
                  
             } 
         } 
     } 


    //document.addEventListener('touchstart',touches,false); 
    //document.addEventListener('touchend',touches,false); 
    //document.addEventListener('touchmove',touches,false); 


var iTimeLine = 0;


$(document).ready(function () {
    
   
    autoScale(false);
    
    //$(function($) { $.preload.images(document) });
     
    $(".viewpage").click(function(){ 
        resetSeconds();
        playLoopAniAndWaitToMenu();
    });


	//set video to autoplay and loop play
	//$("#videobody")[0].loop=G_VIDEO_LOOPPLAY;	//.attr("loop",G_VIDEO_LOOPPLAY);
	//$("#videobody")[0].autoplay=true;		//.attr("autoplay",G_VIDEO_AUTOPLAY);	//設定自動播放


    $("#btnSoundSwitch").click(function(){ 
        switchSound(); 
    });
    
    $(".btnTryItOut").click(function(){ executeExternalAPI(); });
    
    $("#submenu01").click(function(){
        resetSeconds();
        G_PARENT_PAGE="MAINMENU";
        setTargetFlow(1);
        
        var sLeftMarginForChk = "-"+ G_DESIGN_WIDTH + "px";
        
        $("#subpopmenu01").css("top","0px");
        
        if ($("#displaywall").css("margin-left")==sLeftMarginForChk){
            $("#subpopmenu01").fadeIn(200);
            $("#subpopmenu02").fadeOut(100);
    	    $("#subpopmenu03").fadeOut(100);
    	    $("#subpopmenu04").fadeOut(100);
        }else{
            $("#subpopmenu01").css("display","");
            $("#subpopmenu02").css("display","none");
            $("#subpopmenu03").css("display","none");
            $("#subpopmenu04").css("display","none");  
       	    $("#displaywall").animate({"margin-left":sLeftMarginForChk},G_ANIMATE_SPEED);
        }

    	clearInterval(G_TIMER_ID);
        $("#BottomMenu").attr("class", "DesignSelected");
        //$("#HotClickToPrevPage").hide();
        playLoopAniAndWaitToMenu();
		//G_TIMER_ID = setInterval("hideMainMenu()", G_WAIT_SEC); //每5秒更新一次

    });
    $("#submenu02").click(function(){
        resetSeconds();
        G_PARENT_PAGE="MAINMENU";
        setTargetFlow(2);
        
        var sLeftMarginForChk = "-"+ G_DESIGN_WIDTH + "px";
        
        $("#subpopmenu02").css("top","0px");
        
        if ($("#displaywall").css("margin-left")==sLeftMarginForChk){
            $("#subpopmenu02").fadeIn(200);
            $("#subpopmenu01").fadeOut(100);
    	    $("#subpopmenu03").fadeOut(100);
    	    $("#subpopmenu04").fadeOut(100);
        }else{
            $("#subpopmenu02").css("display","");
            $("#subpopmenu01").css("display","none");
            $("#subpopmenu03").css("display","none");
            $("#subpopmenu04").css("display","none");
            $("#displaywall").animate({"margin-left":sLeftMarginForChk},G_ANIMATE_SPEED);
        }
        
    	clearInterval(G_TIMER_ID);
        $("#BottomMenu").attr("class", "ImagingSelected");
        //$("#HotClickToPrevPage").hide();
        playLoopAniAndWaitToMenu();
		//G_TIMER_ID = setInterval("hideMainMenu()", G_WAIT_SEC); //每5秒更新一次

    });
    $("#submenu03").click(function(){
        resetSeconds();
        G_PARENT_PAGE="MAINMENU";
        setTargetFlow(3);
        
        var sLeftMarginForChk = "-"+ G_DESIGN_WIDTH + "px";
        
        $("#subpopmenu03").css("top","0px");
        
        if ($("#displaywall").css("margin-left")==sLeftMarginForChk){
            $("#subpopmenu03").fadeIn(200);
            $("#subpopmenu01").fadeOut(100);
    	    $("#subpopmenu02").fadeOut(100);
    	    $("#subpopmenu04").fadeOut(100);
        }else{
            $("#subpopmenu03").css("display","");
            $("#subpopmenu01").css("display","none");
            $("#subpopmenu02").css("display","none");
            $("#subpopmenu04").css("display","none");  
            $("#displaywall").animate({"margin-left":sLeftMarginForChk},G_ANIMATE_SPEED);   
        }
        
    	
    	clearInterval(G_TIMER_ID);
        $("#BottomMenu").attr("class", "AudioSelected");
        //$("#HotClickToPrevPage").hide();
        playLoopAniAndWaitToMenu();
		//G_TIMER_ID = setInterval("hideMainMenu()", G_WAIT_SEC); //每5秒更新一次

    });
    $("#submenu04").click(function(){
        resetSeconds();
        G_PARENT_PAGE="MAINMENU";
        setTargetFlow(4);
        
        var sLeftMarginForChk = "-"+ G_DESIGN_WIDTH + "px";
        
        $("#subpopmenu04").css("top","0px");
        
        if ($("#displaywall").css("margin-left")==sLeftMarginForChk){
            $("#subpopmenu04").fadeIn(200);
            $("#subpopmenu01").fadeOut(0);
    	    $("#subpopmenu02").fadeOut(0);
    	    $("#subpopmenu03").fadeOut(0);
        }else{
            $("#subpopmenu04").css("display","");
            $("#subpopmenu01").css("display","none");
            $("#subpopmenu02").css("display","none");
            $("#subpopmenu03").css("display","none");  
            $("#displaywall").animate({"margin-left":sLeftMarginForChk},G_ANIMATE_SPEED);    
        }        
    	
    	clearInterval(G_TIMER_ID);
        $("#BottomMenu").attr("class", "InnovationSelected");
        //$("#HotClickToPrevPage").hide();
        playLoopAniAndWaitToMenu();
		//G_TIMER_ID = setInterval("hideMainMenu()", G_WAIT_SEC); //每5秒更新一次

    });
    

    
    $("#BottomMenuItem1").click(function(){$("#submenu01").click();});
    $("#BottomMenuItem2").click(function(){$("#submenu02").click();});
    $("#BottomMenuItem3").click(function(){$("#submenu03").click();});
    $("#BottomMenuItem4").click(function(){$("#submenu04").click();});
    
    //屏障所有預設事件
    blockDefaultEvent("#popmenu");
    blockDefaultEvent("#BottomMenu");
    blockDefaultEvent("#view33");
    blockDefaultEvent("#view42");
    blockDefaultEvent("#view43");
    blockDefaultEvent("#view51");
    blockDefaultEvent("#view52");
    blockDefaultEvent("#view61");
    blockDefaultEvent("#view62");
    blockDefaultEvent("#view63");
    blockDefaultEvent("#view64");

    
    
    
    
    //放大鏡效果 for page-31
    
			$("#view31").on("touchstart",function(e) {
                e.preventDefault();
				flag = true;
			});  
            
			$("#view31").on("touchend",function(e) {
                e.preventDefault();
				flag = false;
			});     
    
             $("#view31").on("touchmove",function(e){
				 //if (flag == false) return;
                
                 //注意:滑鼠座標、觸控座標不會因為ZOOM比例而變動位置，是以實際PIXEL來呈現
                 //也就是ZOOM=1時的x=360的位置，ZOOM改成0.5時，該位置還是360
                 //但是畫面DOOM物件位置、大小、寬高則會改變
                 
                 var oView = $("#ZoomWin31");
                 var pageOffsetX = $(this).offset().left;
                 var pageOffsetY = $(this).offset().top;
                 
                 var viewWidth = parseInt(oView.css("width").replace("px",""));
                 var viewHeight = parseInt(oView.css("height").replace("px",""));
                            
                 var x = (e.originalEvent.touches[0].pageX) / G_BODY_ZOOM - pageOffsetX;
                 var y  = (e.originalEvent.touches[0].pageY) / G_BODY_ZOOM - pageOffsetY;
                
                 //$("#test_info").text(ff(x,1) + "," + ff(y,1));

                 
				if (x >= 0 && x <= G_DESIGN_WIDTH) {
					oView.css("margin-left", (x-(viewWidth/2)) + "px");
					oView.css("background-positionX", 
                                        (x*2-(viewWidth/2))*-1 + "px");

				}
				if (y >= 0 && y <= G_DESIGN_HEIGHT) {
					oView.css("margin-top", (y-(viewHeight/2)) + "px");
					oView.css("background-positionY", 
                                        (y*2-(viewWidth/2))*-1 + "px");
				}
            
            });   
    
			$("#view31").mousemove(function(e) {
                
                 var oView = $("#ZoomWin31");
                 var pageOffsetX = $(this).offset().left;
                 var pageOffsetY = $(this).offset().top;
                 
                 var viewWidth = parseInt(oView.css("width").replace("px",""));
                 var viewHeight = parseInt(oView.css("height").replace("px",""));                
                 var x = e.clientX / G_BODY_ZOOM - pageOffsetX;
                 var y  = e.clientY / G_BODY_ZOOM - pageOffsetY;

                
				if (x >=0 && x <= 1080*G_BODY_ZOOM) {
					oView.css("margin-left", (x-(viewWidth/2)) + "px");
					oView.css("background-positionX", 
                                        (x*2-(viewWidth/2))*-1 + "px");
				}
				if (y >=0 && y <= 1920*G_BODY_ZOOM) {
					oView.css("margin-top", (y-(viewHeight/2)) + "px");
					oView.css("background-positionY", 
                                        (y*2-(viewWidth/2))*-1 + "px");
				}
			});    
    
    //放大鏡效果--end
    //放大鏡效果 for page-32
    
 			$("#view32").on("touchstart",function(e) {
                e.preventDefault();
				flag = true;
			});  
            
			$("#view32").on("touchend",function(e) {
                e.preventDefault();
				flag = false;
			});     
    
             $("#view32").on("touchmove",function(e){
				 //if (flag == false) return;
                
                 //注意:滑鼠座標、觸控座標不會因為ZOOM比例而變動位置，是以實際PIXEL來呈現
                 //也就是ZOOM=1時的x=360的位置，ZOOM改成0.5時，該位置還是360
                 //但是畫面DOOM物件位置、大小、寬高則會改變
                 
                 var oView = $("#ZoomWin32");
                 var pageOffsetX = $(this).offset().left;
                 var pageOffsetY = $(this).offset().top;
                 
                 var viewWidth = parseInt(oView.css("width").replace("px",""));
                 var viewHeight = parseInt(oView.css("height").replace("px",""));
                            
                 var x = (e.originalEvent.touches[0].pageX) / G_BODY_ZOOM - pageOffsetX;
                 var y  = (e.originalEvent.touches[0].pageY) / G_BODY_ZOOM - pageOffsetY;
                
                 //$("#test_info").text(ff(x,1) + "," + ff(y,1));

                 
				if (x >= 0 && x <= G_DESIGN_WIDTH) {
					oView.css("margin-left", (x-(viewWidth/2)) + "px");
					oView.css("background-positionX", 
                                        (x*2-(viewWidth/2))*-1 + "px");

				}
				if (y >= 0 && y <= G_DESIGN_HEIGHT) {
					oView.css("margin-top", (y-(viewHeight/2)) + "px");
					oView.css("background-positionY", 
                                        (y*2-(viewWidth/2))*-1 + "px");
				}
            
            });   
    
			$("#view32").mousemove(function(e) {
                
                
                 var oView = $("#ZoomWin32");
                 var pageOffsetX = $(this).offset().left;
                 var pageOffsetY = $(this).offset().top;
                 
                 var viewWidth = parseInt(oView.css("width").replace("px",""));
                 var viewHeight = parseInt(oView.css("height").replace("px",""));                
                 var x = e.clientX / G_BODY_ZOOM - pageOffsetX;
                 var y  = e.clientY / G_BODY_ZOOM - pageOffsetY;

                
				if (x >=0 && x <= 1080*G_BODY_ZOOM) {
					oView.css("margin-left", (x-(viewWidth/2)) + "px");
					oView.css("background-positionX", 
                                        (x*2-(viewWidth/2))*-1 + "px");
				}
				if (y >=0 && y <= 1920*G_BODY_ZOOM) {
					oView.css("margin-top", (y-(viewHeight/2)) + "px");
					oView.css("background-positionY", 
                                        (y*2-(viewWidth/2))*-1 + "px");
				}
			});      
    
    //放大鏡效果--end
    
    

    
    $("#ImgArrowLeft").click(function(){switchGallery("LEFT");});
    $("#ImgArrowRight").click(function(){switchGallery("RIGHT");});    
    
    $("#btnSwitchLeft").click(function(){switchSkin("LEFT");});
    $("#btnSwitchRight").click(function(){switchSkin("RIGHT");});


    //auto mode
    //出現游標，移動到中心，點擊一下畫面
    
    /*
    $("#cursor").animate({"top":"600px"},1000,function(){
        $("#videobody").click();
        //$("#cursor").hide();
        clearInterval(G_TIMER_ID);
        $("#cursor").animate({"top":"1050px"},800,function(){
            $("#submenu01").click();
            clearInterval(G_TIMER_ID);
            $("#cursor").css("display","none");
            
        });        
    });
    */



    //G_TIMER_ID = setTimeout("showMainMenu()", G_MAIN_DEMO_SEC,function(){

    //});

    var G_TIME_SEC = setInterval("updateSeconds()",1000);
 
    //autoDemo();
    
    

    
    
    $("#btnBackOrExit").click(function(){
        
        //$("#video43")[0].pause();
        $("#ImgSoundWave").removeClass("moveforever");
        
        var sUrlHead = "https://demoflo.com:";
        var RedirectNum = "999";
        
        if (G_PARENT_PAGE=="MAINMENU"){

            showMainMenu();
            
        }else{
            
            var sUrl = sUrlHead + RedirectNum;
            self.location=sUrl;
            //window.open(sUrl, '_blank');            
            //hideMainMenu();
            
        }
        
        
    	
    });
    
    
    //往前一頁
    $("#HotClickToPrevPage").click(function(){
        resetSeconds();
        G_TARGET_PAGE = G_TARGET_PAGE - 1;
        
        var iPageId = (G_TARGET_FLOW+2)*10+G_TARGET_PAGE;        
        
        if (G_TARGET_PAGE<1){

        if (iPageId==30){$("#submenu04").click();return;} 
        if (iPageId==40){$("#submenu01").click();return;}
        if (iPageId==50){$("#submenu02").click();return;} 
        if (iPageId==60){$("#submenu03").click();return;}            
            
            
            G_TARGET_PAGE=1;
            return;
        }
        
        if (G_TARGET_PAGE>0){$("#HotClickToPrevPage").hide();}
        
        var iPageId = (G_TARGET_FLOW+2)*10+G_TARGET_PAGE;
        
        var iTopPos = 0-(G_TARGET_PAGE-1)*G_DESIGN_HEIGHT;
        
        $("#subpopmenu0" + G_TARGET_FLOW).animate({"top":iTopPos + "px"},G_ANIMATE_SPEED/2,"swing"); 
            
        playLoopAniAndWaitToMenu();
        
    	
    }); 
    
    
    //往後一頁
    $("#HotClickToNextPage").click(function(){
        resetSeconds();
        G_TARGET_PAGE = G_TARGET_PAGE + 1;
        
        if (G_TARGET_PAGE>0){$("#HotClickToPrevPage").show();}
        
        var iPageId = (G_TARGET_FLOW+2)*10+G_TARGET_PAGE;
        
        if (iPageId==32){$("#submenu02").click();return;} 
        if (iPageId==42){$("#submenu03").click();return;}
        if (iPageId==52){$("#submenu04").click();return;} 
        if (iPageId==62){$("#submenu01").click();return;}
        
        
        if (iPageId==33){G_GALLERY_IDX=1;}
        
        
        var iTopPos = 0-(G_TARGET_PAGE-1)*G_DESIGN_HEIGHT;
        
        var sThisFlowHeight = $("#subpopmenu0" + G_TARGET_FLOW).css("height");
        sThisFlowHeight = sThisFlowHeight.toLowerCase().replace("px","");
        var iThisFlowHeight = parseInt(sThisFlowHeight);
        
        if (iTopPos > (0-iThisFlowHeight)){
            $("#subpopmenu0" + G_TARGET_FLOW).animate({"top":iTopPos + "px"},G_ANIMATE_SPEED/2,"swing"); 
            playLoopAniAndWaitToMenu();
        }else{
            alert("Page-" + iPageId + " is not found!");
            //$("#HotClickToPrevPage").hide();
        }
        
    	
    });    
    


        
    
    //for Quick View
    clearInterval(G_TIMER_ID);
    
    
    $("#BasePanel").delay(1500).fadeIn(1500,function(){
                
        showMainMenu();

        $(".spinner>div").removeAttr("class");
        $(".spinner").removeAttr("class");
            
    });
    
     onDeviceReady();   //fix 300ms delay on tap
        
    
    //set default
    $("#BottomMenu").attr("class", "DesignSelected");
 
    
    
    



});   //end of (document).ready


    $(function(){
        var iClientWdth = getBrowserWidth();
        // 先取得 #abgne-block-20110112區塊及其寬
        var $block = $('#view41'), 
            _width = $block.width(); //always 1080        
        
        var iLeftMargin = 0;
        var iClickDown = 0;
                
        $block.mousedown(function(evt){ iClickDown =1;});
        $block.mouseup(function(evt){ iClickDown =0;});
        
        // 當滑鼠在 $block 上移動時
        $block.mousemove(function(evt){
            
            if (iClickDown==0){return;}
                
            // 取得目前滑鼠的 x 座標
            var $this = $(this);
            var pageOffsetX = $(this).offset().left;          
            var x = evt.clientX / G_BODY_ZOOM - pageOffsetX;           
            
            // 控制 .first 區塊的寬度
            $("#imgFix41").css({ width: x-(iLeftMargin) });
            $("#img41HTC").css({ width: x-(iLeftMargin) });
            $("#img41Others").css({ width: _width-(x-iLeftMargin) });
            $("#img41SlideBar").css({ left: x-iLeftMargin });            

        });
        

        // 當滑鼠在 $block 上移動時
        $block.on("touchmove",function(evt){
            evt.preventDefault(); 
            // 取得目前滑鼠的 x 座標
            var $this = $(this);
            var pageOffsetX = $(this).offset().left;
            var x = evt.originalEvent.touches[0].pageX / G_BODY_ZOOM - pageOffsetX;          
        
            
            // 控制 .first 區塊的寬度
            $("#imgFix41").css({ width: (x-iLeftMargin) });
            $("#img41HTC").css({ width: x-iLeftMargin });
            $("#img41Others").css({ width: _width-(x-iLeftMargin) });
            $("#img41SlideBar").css({ left: (x-iLeftMargin) });            

        });        
        
    });

    $(function(){
        var iClientWdth = getBrowserWidth();
        // 先取得 #abgne-block-20110112區塊及其寬
        var $block = $('#view44'), 
            _width = $block.width();
        
        var iLeftMargin = 0;
        var iClickDown = 0;
        
        $block.mousedown(function(evt){ iClickDown =1;});
        $block.mouseup(function(evt){ iClickDown =0;});
        
        // 當滑鼠在 $block 上移動時
        $block.on("touchmove",function(evt){
            evt.preventDefault(); 
            // 取得目前滑鼠的 x 座標
            var $this = $(this);
            var pageOffsetX = $(this).offset().left;
            var x = evt.originalEvent.touches[0].pageX / G_BODY_ZOOM - pageOffsetX;  
            
            // 控制 .first 區塊的寬度
            $("#imgFix44").css({ width: x-iLeftMargin    });
            $("#img44withCamera").css({ width: x-iLeftMargin    });
            $("#img44without").css({  width: _width-(x-iLeftMargin)   });
            $("#img44SlideBar").css({ left: x-iLeftMargin     }); 

        });
        
        $block.mousemove(function(evt){
            
            if (iClickDown==0){return;}
                
            // 取得目前滑鼠的 x 座標
            var $this = $(this);
            var pageOffsetX = $(this).offset().left;          
            var x = evt.clientX / G_BODY_ZOOM - pageOffsetX;       
            
            // 控制 .first 區塊的寬度
            $("#imgFix44").css({ width: x-iLeftMargin    });
            $("#img44withCamera").css({ width: x-iLeftMargin    });
            $("#img44without").css({  width: _width-(x-iLeftMargin)   });
            $("#img44SlideBar").css({ left: x-iLeftMargin     }); 

        });        
    });

function resetSeconds(){
    $("#divSeconds").text("0");
}
function updateSeconds(){

    var iSec = parseInt($("#divSeconds").text(),10);

    //alert(iSec);
    iSec=iSec+1;
    
    if (iSec>999){iSec=1;}

    $("#divSeconds").text(iSec);

}


/*
function autoDemo(){

    //移入畫面，點一下開啟主選單
    moveCursorAndClickAndCall("0px","600px",1000,showRootMenu);

    $("#cursor").wait(1000);    

    //點一下第一個按鈕，進入特色頁一
    moveCursorAndClickAndCall("100px","1050px",1000,showMenuItem01);

    hideCursorAndWait(4000);

    //點選返回，回到主選單
    moveCursorAndClickAndCall("370px","1800px",1000,returnToMainMenu);

    hideCursorAndWait(1000);

    //點一下第二個按鈕，進入特色頁二
    moveCursorAndClickAndCall("100px","1250px",1000,showMenuItem02);

    hideCursorAndWait(4000);

    //點一下介紹影片按鈕，播放影片，播完會跳回特色頁二
    moveCursorAndClickAndCall("100px","1500px",1000,function(){$("#ad002").click();});

    hideCursorAndWait(14000);   //依據影片長度設定（秒數+2）

    //點選返回，回到主選單
    moveCursorAndClickAndCall("370px","1800px",1000,returnToMainMenu);

    hideCursorAndWait(1000);   

    //點一下第三個按鈕，進入特色頁三
    moveCursorAndClickAndCall("100px","1450px",1000,showMenuItem03);

    hideCursorAndWait(4000);   

    //點選返回，回到主選單
    moveCursorAndClickAndCall("370px","1800px",1000,returnToMainMenu);

    hideCursorAndWait(1000);   

    //點一下第三個按鈕，進入特色頁四
    moveCursorAndClickAndCall("100px","1650px",1000,showMenuItem04);

    hideCursorAndWait(4000);   

    //點選返回，回到主選單
    moveCursorAndClickAndCall("370px","1800px",1000,returnToMainMenu);

    $("#cursor").wait(1000);  
    $("#cursor").fadeOut(500);

    clearInterval(G_TIMER_ID);
    G_TIMER_ID = setInterval("hideMainMenu()", G_WAIT_SEC); //每5秒更新一次



}
*/







function hideCursorAndWait(inSec){
    $("#cursor").fadeOut(500);
    $("#cursor").wait(inSec);
    $("#cursor").fadeIn(500);
}


function showRootMenu(){
    //clearInterval(G_TIMER_ID);
    $("#videobody").click();   
}

function showMenuItem01(){
    $("#submenu01").click();
    //$("#cursor").fadeOut(50);   
}

function showMenuItem02(){
    $("#submenu02").click();
    //$("#cursor").fadeOut(50);   
}

function showMenuItem03(){
    $("#submenu03").click();
    //$("#cursor").fadeOut(50);   
}

function showMenuItem04(){
    $("#submenu04").click();
    //$("#cursor").fadeOut(50);   
}



$.fn.wait = function(time, type) {
        time = time || 1000;
        type = type || "fx";
        return this.queue(type, function() {
            var self = this;
            setTimeout(function() {
                $(self).dequeue();
            }, time);
        });
    };



function moveCursorAndClick(inX,inY,inSpeed){
    $("#cursor").fadeIn(1).animate({"left":"50%","margin-left":inX,"top":inY},inSpeed-110,function(){
        $("#cursor img").animate({"width":"95px","height":"auto"},50,function(){
            $("#cursor img").animate({"width":"115px","height":"auto"},50);
        });
    });
}

function moveCursorAndClickAndCall(inX,inY,inSpeed,inCallBackFunc){
    $("#cursor").fadeIn(1).animate({"left":"50%","margin-left":inX,"top":inY},inSpeed,function(){
        $("#cursor img").animate({"width":"95px","height":"auto"},50,function(){
            $("#cursor img").animate({"width":"115px","height":"auto"},50,function(){
                setTimeout(inCallBackFunc,1);
            });
        });
    });
}

//取得瀏覽器視窗高度
function getBrowserHeight() { 
    if ($.browser.msie) { 
        return document.compatMode == "CSS1Compat" ? document.documentElement.clientHeight : 
                 document.body.clientHeight; 
    } else { 
        return self.innerHeight; 
    } 
} 
 
//取得瀏覽器視窗寬度 
function getBrowserWidth() { 
    if ($.browser.msie) { 
        return document.compatMode == "CSS1Compat" ? document.documentElement.clientWidth : 
                 document.body.clientWidth; 
    } else { 
        return self.innerWidth; 
    } 
} 

function autoScale(inDebugAMode){
    
    //get truely size
    var iDeviceWidth=getBrowserWidth();//document.body.scrollWidth;
    var iDeviceHeight=getBrowserHeight();//document.body.scrollHeight;
    
    if (inDebugAMode){
        alert("Viewport ( W=" + iDeviceWidth + ", H=" + iDeviceHeight + " )");
    }
    
    var meta=$("#vp");//document.getElementsByTagName('meta');
    
    if (inDebugAMode){    
        //alert("before: " + $("#vp").attr("content"));
    }
    
    
    var iRoomRate = 1;
    
    if (iDeviceWidth>G_DESIGN_WIDTH){
        //iRoomRate = 1;
        iRoomRate = iDeviceWidth / G_DESIGN_WIDTH;  //可能會有鋸齒
    }else{
        iRoomRate = iDeviceWidth / G_DESIGN_WIDTH;
    }
    
    
/*    if (iDeviceWidth<=iDeviceHeight){
        iRoomRate = iDeviceWidth / G_VIEWPORT_WIDTH;
    }else{
        iRoomRate = iDeviceHeight / G_VIEWPORT_WIDTH; 
    }*/
    
    iRoomRate = ff(iRoomRate,4);
    
    //iRoomRate=1.5;    //for debug

    meta.attr("content","width=device-width, initial-scale=" + iRoomRate + ", user-scalable=no, maximum-scale=" + iRoomRate + ", minimum-scale=" + iRoomRate + " ");
    
    document.body.style.zoom = iRoomRate;
    G_BODY_ZOOM = iRoomRate;
    
    if (inDebugAMode){    
        //alert("after: " + $("#vp").attr("content"));
    }else{
        $("body").css("overflow","hidden");
    }
    
    //meta.attr("content","width=device-width, initial-scale=" + iRoomRate + " ");
    
    

}

/*function customScaleThisScreen(inZoom) {
    var contentWidth = document.body.scrollWidth, 
        windowWidth = window.innerWidth, 
        newScale = windowWidth / contentWidth;
    //alert(windowWidth + "/" + contentWidth + "=" + newScale);
    
    document.body.style.zoom = newScale;
    
}*/

function ff(num, pos){ return formatFloat(num, pos); }

function formatFloat(num, pos)
{
  var size = Math.pow(10, pos);
  return Math.round(num * size) / size;
}